#pragma once

extern const char *OBS_VERSION;
extern const char *OBS_VERSION_CANONICAL;
extern const char *OBS_COMMIT;
