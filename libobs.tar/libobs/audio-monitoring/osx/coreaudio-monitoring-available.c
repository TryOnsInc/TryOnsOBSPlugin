#include "../../obs-internal.h"

bool obs_audio_monitoring_available(void)
{
	return true;
}
